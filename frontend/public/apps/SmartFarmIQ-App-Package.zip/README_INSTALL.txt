=== SMART FARM IQ - INSTALLATION GUIDE ===

1. Windows PC:
   Double-click 'SmartFarmIQ-Windows-App.bat' to install the desktop shortcut and run in standalone window mode.

2. Android Phone:
   Open the website in Chrome, click 'Install App', or install 'SmartFarmIQ-Android-App.apk'.

3. Offline Mode:
   The app works with offline caching support automatically!
